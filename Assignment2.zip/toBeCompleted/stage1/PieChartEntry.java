//Jonah Skinner, 44908415

package toBeCompleted.stage1;

public class PieChartEntry {
	private double data;
	private int red, green, blue;

	/**
	 * DO NOT MODIFY
	 * @return
	 */
	public double getData() {
		return data;
	}
	
	/**
	 * DO NOT MODIFY
	 * @return
	 */
	public int getRed() {
		return red;
	}
	
	/**
	 * DO NOT MODIFY
	 * @return
	 */
	public int getGreen() {
		return green;
	}
	
	/**
	 * DO NOT MODIFY
	 * @return
	 */
	public int getBlue() {
		return blue;
	}
	
	/**
	 * set instance variable data to 
	 *     0 if parameter is less than 0, else 
	 *     100 if parameter is more than 100, else
	 *     the value of parameter
	 * @param data
	 * 
	 */
	public void setData(double data) {
		if(data<0){
			data = 0;
		}
		if(data>100){
			data =100;
		}
		this.data = data;
		
		//to be completed
	}
	
	/**
	 * set instance variable red to 
	 *     0 if parameter is less than 0, else 
	 *     255 if parameter is more than 255, else
	 *     the value of parameter
	 * @param red
	 */
	public void setRed(int red) {
		if(red<0){
			red = 0;
		}
		if(red>255){
			red = 255;
		}
		this.red = red;
		//to be completed
	}
	
	/**
	 * set instance variable green to 
	 *     0 if parameter is less than 0, else 
	 *     255 if parameter is more than 255, else
	 *     the value of parameter
	 * @param green
	 */
	public void setGreen(int green) {
		if(green<0){
			green = 0;
		}
		if(green>255){
			green =255;
		}
		this.green = green;
		//to be completed
	}
	
	/**
	 * set instance variable blue to 
	 *     0 if parameter is less than 0, else 
	 *     255 if parameter is more than 255, else
	 *     the value of parameter
	 * @param blue
	 */
	public void setBlue(int blue) {
		if(blue<0){
			blue = 0;
		}
		if(blue>255){
			blue =255;
		}
		this.blue = blue;
		//to be completed
	}
	
	/**
	 * set the instance variables to the values of the parameters using the 
	 * individual setters
	 * @param red
	 * @param green
	 * @param blue
	 */
	public void setColor(int red, int green, int blue) {
		setRed(red);
		setGreen(green);
		setBlue(blue);
		
		//to be completed
	}
	
	/**
	 * DO NOT MODIFY
	 */
	public PieChartEntry() {
		data = 0;
		red = 0;
		green = 0;
		blue = 0;
	}
			
	/**
	 * 5 marks
	 * set instance variable data to parameter data using the setter
	 * set colors based on the following rule:
	 * if index is a multiple of 8, color should be red = 0, green = 0, blue = 0
	 * if index remainder 8 is 1, color should be red = 255, green = 0, blue = 0
	 * if index remainder 8 is 2, color should be red = 0, green = 255, blue = 0
	 * if index remainder 8 is 3, color should be red = 0, green = 0, blue = 255
	 * if index remainder 8 is 4, color should be red = 255, green = 255, blue = 0
	 * if index remainder 8 is 5, color should be red = 255, green = 0, blue = 255
	 * if index remainder 8 is 6, color should be red = 0, green = 255, blue = 255
	 * if index remainder 8 is 7, color should be red = 255, green = 255, blue = 255
	 * @param data
	 * @param index
	 */
	public PieChartEntry(double data, int index) {
		setData(data);
		if(index%8==0){
			red=0;
			green=0;
			blue=0;
		}
		if(index%8==1){
			red=255;
			green=0;
			blue=0;
		}
		if(index%8==2){
			red=0;
			green=255;
			blue=0;
		}
		if(index%8==3){
			red=0;
			green=0;
			blue=255;
		}
		if(index%8==4){
			red=255;
			green=255;
			blue=0;
		}
		if(index%8==5){
			red=255;
			green=0;
			blue=255;
		}
		if(index%8==6){
			red=0;
			green=255;
			blue=255;
		}
		if(index%8==7){
			red=255;
			green=255;
			blue=255;
		}
		//to be completed;
	}
}
