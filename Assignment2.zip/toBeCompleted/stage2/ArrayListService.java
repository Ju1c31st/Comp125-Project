//Jonah Skinner, 44908415

package toBeCompleted.stage2;

import java.util.ArrayList;

public class ArrayListService {
	/**
	 * 
	 * @param list
	 * @return total of the items of list. return 0 if list is null
	 */
	public static double total(ArrayList<Double> list) {
		if(list == null){
			return 0;
		}
		double sum = 0;
		for(int i=0; i<list.size();i++){
			sum+=list.get(i);
		}
		return sum; //to be completed
	}

	/**
	 * "fix" the list based on the following rules.
	 * 
	 * a. if list is null, list should become a list with a single item, 100.0
	 * 
	 * b. if total of list is negative, list should become a list with a single item, 100.0
	 * 
	 * c. if total of list is less than 100, add a single item with the short-fall at the 
	 *    beginning of the list. for example, if list = [30, 60], list should become [10, 30, 60]
	 *    
	 * d. if total of list is more than 100, remove the first item and make a recursive call to fix.
	 *    For example, if list = [40, 30, 80], list should become [20, 80]
	 * 
	 * you CAN write a non-recursive solution for this in order to move on to the next
	 * stage, however you won't get marks for this method if the solution is not recursive
	 * 
	 * @param list
	 */
	public static void fix(ArrayList<Double> list) {
		if(list == null){
			list = new ArrayList<Double>(); //because we have effectively no list we must make a new one
			list.add(100.0); //now we can add stuff into it :) 
		}
		if(total(list) < 0){ //b
			list.clear();
			list.set(0,100.0);
		}
		if(total(list) < 100.0 && total(list) > 0.0){ //c
			double result = 0;
			for( Double x : list ){
				 if( x > 0)
				 result += x;
			}
			result-=100;
			list.add(0, Math.abs(result));
		}
		if(total(list) > 100){//d
			list.remove(0);
			fix(list);
		}
	}
	//to be completed
}