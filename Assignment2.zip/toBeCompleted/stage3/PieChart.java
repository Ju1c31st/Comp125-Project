//Jonah Skinner, 44908415

package toBeCompleted.stage3;

import java.util.ArrayList;
import toBeCompleted.stage1.PieChartEntry;
import toBeCompleted.stage2.ArrayListService;

public class PieChart {
	private ArrayList<PieChartEntry> entries;
	private int centerX, centerY;
	private int radius;

	/**
	 * DO NOT MODIFY
	 * @return
	 */
	public ArrayList<PieChartEntry> getEntries() {
		return entries;
	}

	/**
	 * DO NOT MODIFY
	 * @return centerX
	 */
	public int getCenterX() {
		return centerX;
	}

	/**
	 * DO NOT MODIFY
	 * @return centerY
	 */
	public int getCenterY() {
		return centerY;
	}

	/**
	 * DO NOT MODIFY
	 * @return radius
	 */
	public int getRadius() {
		return radius;
	}

	/**
	 * DO NOT MODIFY
	 * @return: number of items in the PieChart
	 */
	public int size() {
		if(entries == null)
			return 0;
		return entries.size();
	}

	/**
	 * if parameter is less than 0, instance variable centerX becomes 0, else
	 * set instance variable centerX to parameter.
	 * @param centerX
	 */
	public void setCenterX(int centerX) {
		if(centerX < 0){
			centerX = 0;
		}
		this.centerX = centerX;
		//to be completed
	}

	/**
	 * if parameter is less than 0, instance variable centerY becomes 0, else
	 * set instance variable centerY to parameter.
	 * @param centerY
	 */
	public void setCenterY(int centerY) {
		if(centerY < 0){
			centerY = 0;
		}
		this.centerY = centerY;
		//to be completed
	}

	/**
	 * if parameter is less than 20, instance variable radius becomes 20, else
	 * set instance variable radius to parameter.
	 * @param radius
	 */
	public void setRadius(int radius) {
		if(radius < 20){
			radius = 20;
		}
		this.radius = radius;
		//to be completed
	}

	/**
	 * if list is null, entries becomes a list of a single PieChartEntry object
	 * with data = 100, color = 0, 0, 0
	 * else
	 * step 1: fix the list by calling the static method fix(ArrayList<Double>) 
	 * in ArrayListService class
	 * step 2:
	 * populate the instance variable (ArrayList of PieChartEntry objects)
	 * using the data in the parameter.
	 * Using a loop, for each item of the list at index i, 
	 * add an entry in the instance variable entries with 
	 * data = list.get(i) and index i
	 * 
	 * @param list
	 */
	private void setEntries(ArrayList<Double> list) {
		if(list == null){
			list = new ArrayList<Double>();
			list.add(100.0);
			setCenterX(0);
			setCenterY(0);
			setRadius(0);
		} else {
			ArrayListService.fix(list);
			entries = new ArrayList<PieChartEntry>();
			for(int i=0; i<list.size(); i++){
				entries.add(new PieChartEntry(list.get(i), 0));
			}
		}

		//to be completed
	}

	/**
	 * DO NOT MODIFY
	 */
	public PieChart() {
		entries = new ArrayList<PieChartEntry>();
		entries.add(new PieChartEntry(100,0));
		centerX = 100;
		centerY = 100;
		radius = 100;
	}

	/**
	 * set each instance variable to the corresponding parameter using the setters
	 * @param list
	 * @param cx
	 * @param cy
	 * @param rad
	 */
	public PieChart(ArrayList<Double> list, int cx, int cy, int rad) {
		setEntries(list);
		setCenterX(cx);
		setCenterY(cy);
		setRadius(rad);
		//to be completed
	}
	/*
	 * 
	 * Helper Method which does the summation of 2 lists 
	 * from this we can then simply multiply the weight to each of the values given in each 
	 * Arraylist and then we can find the correct values of each item in the arraylist
	 * 
	 * 
	 * ijust dont know how to draw out the arraylist values in a object 
	 * and then apply this and the weight 
	 * and then put it back into the object 
	 * so annoying not knowing the code@@!!
	 * 	
	 */	

	//	public static ArrayList<Double> sum(ArrayList<Double> list1, ArrayList<Double> list2){
	//		if(list1 == null || list2 == null){
	//			return null;
	//		}
	//		ArrayList<Double> result = new ArrayList<Double>();
	//
	//		for(int i = 0; i<list1.size(); i++){
	//			double sum = 0;
	//			sum = list1.get(i)+list2.get(i);
	//			result.add(sum);
	//		}
	//		return result;
	//
	//	}


	/**
	 * merge the two pie charts to produce a composite pie chart.
	 * if the parameter object is null, return null
	 * if the weight is less than 0 or more than 1, return null
	 * if the calling object and parameter object do not have the same size(), return null
	 * 
	 * otherwise, return a PieChart object that has the same number
	 * of items as calling object and parameter object, and,
	 * 
	 * item at index i in the merged PieChart =
	 * item at index i in calling object * weight + 
	 * item at index i in parameter object * (1 - weight) 
	 * 
	 * the other attributes of the merged PieChart should be the 
	 * same as those of the calling object
	 * 
	 * @param other
	 * @param weight
	 * @return
	 */
	public PieChart merge(PieChart other, double weight) {
		if(entries == null){
			return null; //passed
		}
		if(weight < 0 || weight > 1){
			return null; 
		}
		if(entries.size() != other.entries.size()){
			return null; //passed & makes sure sizes are same.
		}
		ArrayList<Double> list = new ArrayList<Double>();
		for(int i=0; i<this.entries.size(); i++){ 
			Double weight2 = 1.0-weight;
			Double item = (this.entries.get(i).getData()*weight)+(other.entries.get(i).getData()*(weight2));
			list.add(i, item);
		}
		PieChart merged = new PieChart(list, this.centerX, this.centerY, this.radius);
		return merged;
		//to be completed

	}
}



